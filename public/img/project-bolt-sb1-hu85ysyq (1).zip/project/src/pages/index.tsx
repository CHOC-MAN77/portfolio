import Head from 'next/head'
import { motion } from 'framer-motion'
import { CodeBracketIcon, CommandLineIcon, CpuChipIcon, WindowIcon } from '@heroicons/react/24/outline'

export default function Home() {
  return (
    <>
      <Head>
        <title>Portfolio Développeur Web</title>
        <meta name="description" content="Portfolio professionnel de développeur web full-stack" />
        <link rel="icon" href="/favicon.ico" />
      </Head>

      <div className="min-h-screen bg-white">
        {/* Hero Section */}
        <section className="px-4 md:px-6 lg:px-8 max-w-7xl mx-auto pt-20 pb-32">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="text-center"
          >
            <div className="flex justify-center mb-6">
              <code className="bg-gray-100 text-primary px-4 py-1 rounded-full text-sm">
                console.log('Hello, World! 👋')
              </code>
            </div>
            <h1 className="text-5xl md:text-7xl font-bold text-primary mb-6">
              Développeur Web Full-Stack
            </h1>
            <p className="text-xl text-secondary max-w-2xl mx-auto mb-8">
              Je crée des applications web modernes et performantes avec les dernières technologies
            </p>
            <div className="flex gap-4 justify-center">
              <button className="bg-primary text-white px-8 py-4 rounded-full text-lg font-medium hover:bg-opacity-90 transition-colors">
                Voir mes projets
              </button>
              <button className="border-2 border-primary text-primary px-8 py-4 rounded-full text-lg font-medium hover:bg-gray-50 transition-colors">
                GitHub
              </button>
            </div>
          </motion.div>
        </section>

        {/* Technologies Section */}
        <section className="bg-gray-50 py-24">
          <div className="px-4 md:px-6 lg:px-8 max-w-7xl mx-auto">
            <h2 className="text-3xl font-bold text-center mb-16">Stack Technique</h2>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
              {technologies.map((tech, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1 }}
                  className="flex flex-col items-center"
                >
                  <img 
                    src={tech.icon} 
                    alt={tech.name}
                    className="w-16 h-16 mb-4"
                  />
                  <h3 className="text-lg font-semibold">{tech.name}</h3>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {/* Services Section */}
        <section className="py-24">
          <div className="px-4 md:px-6 lg:px-8 max-w-7xl mx-auto">
            <h2 className="text-3xl font-bold text-center mb-16">Expertise</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
              {services.map((service, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.2 }}
                  className="bg-white p-8 rounded-2xl shadow-sm border border-gray-100"
                >
                  <service.icon className="w-8 h-8 text-primary mb-4" />
                  <h3 className="text-xl font-semibold mb-4">{service.title}</h3>
                  <p className="text-secondary">{service.description}</p>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {/* Projects Section */}
        <section className="bg-gray-50 py-24">
          <div className="px-4 md:px-6 lg:px-8 max-w-7xl mx-auto">
            <h2 className="text-3xl font-bold text-center mb-16">Projets Récents</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              {projects.map((project, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0 }}
                  whileInView={{ opacity: 1 }}
                  className="bg-white rounded-2xl overflow-hidden shadow-sm"
                >
                  <img
                    src={project.image}
                    alt={project.title}
                    className="w-full h-[300px] object-cover"
                  />
                  <div className="p-8">
                    <h3 className="text-2xl font-bold mb-2">{project.title}</h3>
                    <p className="text-secondary mb-4">{project.description}</p>
                    <div className="flex gap-2 mb-6">
                      {project.technologies.map((tech, i) => (
                        <span 
                          key={i}
                          className="bg-gray-100 text-primary px-3 py-1 rounded-full text-sm"
                        >
                          {tech}
                        </span>
                      ))}
                    </div>
                    <div className="flex gap-4">
                      <button className="bg-primary text-white px-6 py-2 rounded-full">
                        Voir le projet
                      </button>
                      <button className="border border-primary text-primary px-6 py-2 rounded-full">
                        Code source
                      </button>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {/* Contact Section */}
        <section className="bg-primary text-white py-24">
          <div className="px-4 md:px-6 lg:px-8 max-w-7xl mx-auto text-center">
            <h2 className="text-3xl font-bold mb-8">Travaillons Ensemble</h2>
            <p className="text-xl mb-12 max-w-2xl mx-auto">
              Vous avez un projet ? Je suis disponible pour des missions freelance.
            </p>
            <div className="flex gap-4 justify-center">
              <button className="bg-white text-primary px-8 py-4 rounded-full text-lg font-medium hover:bg-opacity-90 transition-colors">
                Me Contacter
              </button>
              <button className="border-2 border-white text-white px-8 py-4 rounded-full text-lg font-medium hover:bg-white hover:bg-opacity-10 transition-colors">
                Mon CV
              </button>
            </div>
          </div>
        </section>
      </div>
    </>
  )
}

const technologies = [
  {
    name: "React",
    icon: "https://cdn.jsdelivr.net/gh/devicons/devicon/icons/react/react-original.svg"
  },
  {
    name: "TypeScript",
    icon: "https://cdn.jsdelivr.net/gh/devicons/devicon/icons/typescript/typescript-original.svg"
  },
  {
    name: "Node.js",
    icon: "https://cdn.jsdelivr.net/gh/devicons/devicon/icons/nodejs/nodejs-original.svg"
  },
  {
    name: "Next.js",
    icon: "https://cdn.jsdelivr.net/gh/devicons/devicon/icons/nextjs/nextjs-original.svg"
  },
  {
    name: "PostgreSQL",
    icon: "https://cdn.jsdelivr.net/gh/devicons/devicon/icons/postgresql/postgresql-original.svg"
  },
  {
    name: "Tailwind CSS",
    icon: "https://cdn.jsdelivr.net/gh/devicons/devicon/icons/tailwindcss/tailwindcss-plain.svg"
  },
  {
    name: "Docker",
    icon: "https://cdn.jsdelivr.net/gh/devicons/devicon/icons/docker/docker-original.svg"
  },
  {
    name: "Git",
    icon: "https://cdn.jsdelivr.net/gh/devicons/devicon/icons/git/git-original.svg"
  }
]

const services = [
  {
    title: "Développement Frontend",
    description: "Création d'interfaces utilisateur réactives et performantes avec React et Next.js",
    icon: WindowIcon
  },
  {
    title: "Développement Backend",
    description: "APIs RESTful et GraphQL avec Node.js et bases de données SQL/NoSQL",
    icon: CodeBracketIcon
  },
  {
    title: "Architecture Cloud",
    description: "Déploiement et maintenance d'applications sur AWS et Vercel",
    icon: CpuChipIcon
  },
  {
    title: "DevOps",
    description: "Mise en place de CI/CD et conteneurisation avec Docker",
    icon: CommandLineIcon
  }
]

const projects = [
  {
    title: "E-commerce Next.js",
    description: "Plateforme e-commerce moderne avec paiement Stripe et gestion de produits",
    image: "https://via.placeholder.com/600x400",
    technologies: ["Next.js", "TypeScript", "Tailwind CSS", "Stripe"]
  },
  {
    title: "Dashboard Analytics",
    description: "Tableau de bord d'analyse de données en temps réel avec graphiques",
    image: "https://via.placeholder.com/600x400",
    technologies: ["React", "D3.js", "Node.js", "WebSocket"]
  }
]