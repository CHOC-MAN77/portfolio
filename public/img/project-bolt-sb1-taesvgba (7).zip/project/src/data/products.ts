import { Product } from '@/types/product';

export const products: Product[] = [
  {
    id: 1,
    name: 'Satellite',
    slug: 'satellite',
    price: 100,
    image: '/images/satellite.jpg'
  },
  {
    id: 2,
    name: 'Sand',
    slug: 'sand',
    price: 100,
    image: '/images/sand.jpg'
  },
  {
    id: 3,
    name: 'Ocean',
    slug: 'ocean',
    price: 100,
    image: '/images/ocean.jpg'
  },
  {
    id: 4,
    name: 'Sangre',
    slug: 'sangre',
    price: 100,
    image: '/images/sangre.jpg'
  },
  {
    id: 5,
    name: 'Fraise',
    slug: 'fraise',
    price: 100,
    image: '/images/fraise.jpg'
  },
  {
    id: 6,
    name: 'Dune',
    slug: 'dune',
    price: 100,
    image: '/images/dune.jpg'
  }
];